#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 18 21:49:28 2020

@author: harrisonbueno
"""

def gradient1(b_user, b_item, global_mu):
    r_ui=pd.DataFrame(index=b_user.index.values,columns=b_item.index.values)
    r_ui=r_ui.astype(float)

    for i in range(b_item.shape[0]):
        for u in range(b_user.shape[0]):
            r_ui[b_item.index[i]][b_user.index[u]]=round(global_mu+
                b_user["Deviation"][b_user.index[u]]+
                b_item["Deviation"][b_item.index[i]],2)
    return r_ui


###output residual or e_ui
def gradient2(b_user, b_item, global_mu, df):
    e_ui=pd.DataFrame(index=b_user.index.values,
                      columns=b_item.index.values)
    e_ui=e_ui.astype(float)
    
    for i in range(b_item.shape[0]):
        for u in range(b_user.shape[0]):
            e_ui[b_item.index[i]][b_user.index[u]]=round(
                df[b_item.index[i]][b_user.index[u]]-
                global_mu-
                b_user["Deviation"][b_user.index[u]]-
                b_item["Deviation"][b_item.index[i]],2)
    return e_ui
